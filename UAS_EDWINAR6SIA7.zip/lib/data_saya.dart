class DataSaya {
  static String nama = "EDWINAR SIHOTANG";
  static String gambar = "assets/mahasiswa/sela.jpg";
}
